// This group provides endpoints for user login, signup, and reset password, returning authentication tokens and user records.
api_group Authentication {
  canonical = "ygUcA_ly"
  tags = ["xano:quick-start"]
  guid = "mStN7opEFrpR7by1Jd41lDokIo4"
}