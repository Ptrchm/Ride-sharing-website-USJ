// Retrieve the authenticated user's details and their profile information.
query "auth/me" verb=GET {
  api_group = "Authentication"
  auth = "user"

  input {
  }

  stack {
    // Retrieve the user record along with their profile data using an addon
    db.get user {
      field_name = "id"
      field_value = $auth.id
    } as $user
  }

  response = $user
  guid = "R_7_R-8SS4-WfM3GS4ieMO0_vls"
}