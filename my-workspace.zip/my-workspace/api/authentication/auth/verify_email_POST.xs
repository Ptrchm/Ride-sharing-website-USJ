// Verify a user's email using a one-time token.
query "auth/verify-email" verb=POST {
  api_group = "Authentication"

  input {
    text token filters=trim
  }

  stack {
    db.query user {
      where = $db.user.email_verification_token == $input.token
      return = {type: "single"}
    } as $user
  
    precondition ($user != null) {
      error_type = "notfound"
      error = "Invalid verification token."
    }
  
    precondition (
      $user.email_verification_token_expires_at == null ||
      $user.email_verification_token_expires_at > now
    ) {
      error_type = "accessdenied"
      error = "Verification token expired."
    }
  
    db.edit user {
      field_name = "id"
      field_value = $user.id
      data = {
        is_active                          : true
        email_verification_token           : null
        email_verification_token_expires_at: null
      }
    } as $updated
  }

  response = {message: "Email verified."}
  guid = "pQ9sVn3h-verify_email_post"
}
