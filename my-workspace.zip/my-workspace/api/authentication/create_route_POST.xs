// Creates a new route for a driver offering a ride.
query create_route verb=POST {
  api_group = "Authentication"
  auth = ""

  input {
    // Description of the route
    text route_description filters=trim
  
    // Name of the departure location
    text departure_location_name filters=trim
  
    // Name of the arrival location
    text arrival_location_name filters=trim
  
    // Departure time of the ride in epoch milliseconds
    timestamp departure_time
  
    // Number of available seats for the ride
    int available_seats filters=min:1
  
    // Price charged per seat for the ride
    decimal price_per_seat filters=min:0
  }

  stack {
    // Add the new route to the database linked to the authenticated user
    db.add route {
      data = {
        user_id                : $auth.id
        route_description      : $input.route_description
        departure_location_name: $input.departure_location_name
        arrival_location_name  : $input.arrival_location_name
        departure_time         : $input.departure_time
        available_seats        : $input.available_seats
        price_per_seat         : $input.price_per_seat
      }
    } as $new_route
  }

  response = {id: $new_route.id}
  guid = "eQ4q9CfCSY5Fq0Ls1EwgmB3V-fg"
}