// Query all user records
query user verb=GET {
  api_group = "Authentication"

  input {
  }

  stack {
    db.query user {
      return = {type: "list"}
    } as $model
  }

  response = $model
  guid = "X75dQ73-mNFtM-8Eeor8-5fB4KI"
}