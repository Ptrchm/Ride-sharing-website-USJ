// Authenticate a user and return an auth token
query login verb=POST {
  api_group = "Authentication"

  input {
    // User's email address
    email email {
      sensitive = true
    }
  
    // User's password
    text password {
      sensitive = true
    }
  }

  stack {
    // Fetch the user record based on the provided email
    db.query user {
      where = $db.user.email == $input.email
      return = {type: "single"}
    } as $user
  
    // Check if a user record was found
    precondition ($user != null) {
      error_type = "accessdenied"
      error = "Invalid email or password."
    }
  
    // Compare the input password with the stored hashed password
    security.check_password {
      text_password = $input.password
      hash_password = $user.password
    } as $is_valid
  
    // Verify the password is correct
    precondition ($is_valid) {
      error_type = "accessdenied"
      error = "Invalid email or password."
    }
  
    // Generate an authentication token upon successful password verification
    security.create_auth_token {
      table = "user"
      extras = {}
      expiration = 86400
      id = $user.id
    } as $auth_token
  }

  response = {authToken: $auth_token}
  guid = "UCDluwjWV2iHGh_rqMX3G7JGFVs"
}