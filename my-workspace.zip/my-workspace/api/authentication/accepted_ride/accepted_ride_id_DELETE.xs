// Delete accepted_ride record
query "accepted_ride/{accepted_ride_id}" verb=DELETE {
  api_group = "Authentication"

  input {
    int accepted_ride_id? filters=min:1
  }

  stack {
    db.del accepted_ride {
      field_name = "id"
      field_value = $input.accepted_ride_id
    }
  }

  response = null
  guid = "TvgRtp9To5ylNHeavRx-m014XYw"
}