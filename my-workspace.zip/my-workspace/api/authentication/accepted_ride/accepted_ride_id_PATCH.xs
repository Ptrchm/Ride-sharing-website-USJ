// Edit accepted_ride record
query "accepted_ride/{accepted_ride_id}" verb=PATCH {
  api_group = "Authentication"

  input {
    int accepted_ride_id? filters=min:1
    dblink {
      table = "accepted_ride"
    }
  }

  stack {
    util.get_raw_input {
      encoding = "json"
      exclude_middleware = false
    } as $raw_input
  
    db.patch accepted_ride {
      field_name = "id"
      field_value = $input.accepted_ride_id
      data = `$input|pick:($raw_input|keys)`|filter_null|filter_empty_text
    } as $model
  }

  response = $model
  guid = "qa8tQ5F_mTGDZv2ZVwsBxmSdkNQ"
}