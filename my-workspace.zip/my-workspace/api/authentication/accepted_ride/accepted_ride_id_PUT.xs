// Update accepted_ride record
query "accepted_ride/{accepted_ride_id}" verb=PUT {
  api_group = "Authentication"

  input {
    int accepted_ride_id? filters=min:1
    dblink {
      table = "accepted_ride"
    }
  }

  stack {
    db.edit accepted_ride {
      field_name = "id"
      field_value = $input.accepted_ride_id
      data = {
        ride_request_id  : $input.ride_request_id
        route_id         : $input.route_id
        passenger_user_id: $input.passenger_user_id
        driver_user_id   : $input.driver_user_id
        seats_booked     : $input.seats_booked
        status           : $input.status
      }
    } as $model
  }

  response = $model
  guid = "CCfOGAoHOBaCQdNakUVFq9Iukb8"
}