// Get accepted_ride record
query "accepted_ride/{accepted_ride_id}" verb=GET {
  api_group = "Authentication"

  input {
    int accepted_ride_id? filters=min:1
  }

  stack {
    db.get accepted_ride {
      field_name = "id"
      field_value = $input.accepted_ride_id
    } as $model
  
    precondition ($model != null) {
      error_type = "notfound"
      error = "Not Found"
    }
  }

  response = $model
  guid = "FfAVIOxPOrVTFbhV3cDjaxic3V8"
}