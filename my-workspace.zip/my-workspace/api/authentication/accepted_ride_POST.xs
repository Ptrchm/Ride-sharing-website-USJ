// Add accepted_ride record
query accepted_ride verb=POST {
  api_group = "Authentication"

  input {
    dblink {
      table = "accepted_ride"
    }
  }

  stack {
    db.add accepted_ride {
      data = {
        created_at       : "now"
        ride_request_id  : $input.ride_request_id
        route_id         : $input.route_id
        passenger_user_id: $input.passenger_user_id
        driver_user_id   : $input.driver_user_id
        seats_booked     : $input.seats_booked
        status           : $input.status
      }
    } as $model
  }

  response = $model
  guid = "zjWP4Xk4HW_nzE95ts2cdYohaj0"
}