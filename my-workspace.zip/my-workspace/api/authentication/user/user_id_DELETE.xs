// Delete user record
query "user/{user_id}" verb=DELETE {
  api_group = "Authentication"

  input {
    int user_id? filters=min:1
  }

  stack {
    db.del user {
      field_name = "id"
      field_value = $input.user_id
    }
  }

  response = null
  guid = "SvMNyBU_8MVC-a1MFHjkad6Sarw"
}