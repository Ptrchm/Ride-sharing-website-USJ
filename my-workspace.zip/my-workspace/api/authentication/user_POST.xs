// Add user record
query user verb=POST {
  api_group = "Authentication"

  input {
    dblink {
      table = "user"
    }
  }

  stack {
    db.add user {
      data = {
        created_at                         : "now"
        full_name                          : $input.full_name
        email                              : $input.email
        password                           : $input.password
        password_reset                     : $input.password_reset
        phone_number                       : $input.phone_number
        is_active                          : $input.is_active
        email_verification_token           : $input.email_verification_token
        email_verification_token_expires_at: $input.email_verification_token_expires_at
        account_id                         : $input.account_id
      }
    } as $model
  }

  response = $model
  guid = "sHnj5qhZWFllG-WdVkRVaOS20Vo"
}