// Query all accepted_ride records
query accepted_ride verb=GET {
  api_group = "Authentication"

  input {
  }

  stack {
    db.query accepted_ride {
      return = {type: "list"}
    } as $model
  }

  response = $model
  guid = "mBERQs8WLH5iJVWU2lM_LjwwxtU"
}