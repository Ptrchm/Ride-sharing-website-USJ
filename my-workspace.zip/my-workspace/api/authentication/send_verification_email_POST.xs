// Sends an HTML verification email using Resend API directly.
query "send-verification-email" verb=POST {
  api_group = "Authentication"
  auth = "user"

  input {
  }

  stack {
    db.get user {
      field_name = "id"
      field_value = $auth.id
    } as $user
  
    precondition ($user != null) {
      error_type = "notfound"
      error = "User not found."
    }
  
    // Reuse an existing, non-expired token if present. Otherwise generate a new one.
    var $token {
      value = $user.email_verification_token
    }
  
    conditional {
      if (
        $token == null ||
        $user.email_verification_token_expires_at == null ||
        $user.email_verification_token_expires_at < now
      ) {
        security.create_uuid as $new_token
      
        var.update $token {
          value = $new_token
        }
      
        db.edit user {
          field_name = "id"
          field_value = $auth.id
          data = {
            is_active                          : false
            email_verification_token           : $token
            email_verification_token_expires_at: (now|add_secs_to_timestamp:(86400|to_int))
          }
        } as $user
      }
    }
  
    // Construct the verification link using the frontend base URL and token
    var $verification_link {
      value = $env.FRONTEND_BASE_URL ~ "/verify-email?token=" ~ $token
    }
  
    // Generate the HTML body for the email
    util.template_engine {
      value = """
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
            <h2>Welcome to our Carpooling App!</h2>
            <p>Hello,</p>
            <p>Please verify your email address by clicking the button below:</p>
            <p style="text-align: center; margin: 30px 0;">
              <a href="{{ var.verification_link }}" style="background-color: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">Verify Email</a>
            </p>
            <p>Or copy and paste this link into your browser:</p>
            <p><a href="{{ var.verification_link }}">{{ var.verification_link }}</a></p>
            <p>If you did not request this, please ignore this email.</p>
          </div>
        """
    } as $html_body
  
    // Call Resend API directly to send the email
    api.request {
      url = "https://api.resend.com/emails"
      method = "POST"
      params = {}
        |set:"from":"Carpooling App <noreply@yourdomain.com>"
        |set:"to":([]|push:$user.email)
        |set:"subject":"Verify your email address"
        |set:"html":$html_body
      headers = []
        |push:"Authorization: Bearer " ~ $env.RESEND_API_KEY
        |push:"Content-Type: application/json"
      timeout = 30
    } as $resend_response
  }

  response = $resend_response
  guid = "rUG4j5xdPgFjFGPIKXqnl6q3lKo"
}
