// Handles user login and logs a 'user_login' event.
query "auth/login" verb=POST {
  api_group = "Event Logs"

  input {
    // User's email address
    email email filters=trim|lower {
      sensitive = true
    }
  
    // User's password
    text password {
      sensitive = true
    }
  }

  stack {
    // Get the user by email
    db.get user {
      field_name = "email"
      field_value = $input.email
    } as $user
  
    // Ensure user exists
    precondition ($user != null) {
      error_type = "accessdenied"
      error = "Invalid email or password."
    }
  
    // Check if the password matches
    security.check_password {
      text_password = $input.password
      hash_password = $user.password
    } as $is_valid
  
    // Ensure password is valid
    precondition ($is_valid) {
      error_type = "accessdenied"
      error = "Invalid email or password."
    }
  
    // Create authentication token
    security.create_auth_token {
      table = "user"
      extras = {}
      expiration = 86400
      id = $user.id
    } as $authToken
  
    // Log the user login event
    db.add event_log {
      data = {
        action  : "user_login"
        user_id : $user.id
        metadata: {ip: $env.$remote_ip}
      }
    } as $event_log
  }

  response = {authToken: $authToken, user: $user}
  guid = "n4gUs4_Q0LZ3I9xDjyexOQjzLgg"
}