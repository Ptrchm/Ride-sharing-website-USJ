// Contains API Endpoints for reports of event logs
api_group "Event Logs" {
  canonical = "VwkRVjqj"
  swagger = {token: "394JnWYKvLHg4LgXYQxWceSVCDY"}
  tags = ["xano:quick-start"]
  guid = "pCvmS16aE4mg-tU4yHXiRdic4-o"
}