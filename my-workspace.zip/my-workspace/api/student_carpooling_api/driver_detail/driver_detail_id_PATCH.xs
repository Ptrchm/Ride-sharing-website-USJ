// Edit driver_detail record (used for approve/reject and profile updates).
query "driver_detail/{driver_detail_id}" verb=PATCH {
  api_group = "Student Carpooling API"
  auth = "user"

  input {
    int driver_detail_id? filters=min:1
    dblink {
      table = "driver_detail"
    }
  }

  stack {
    db.get driver_detail {
      field_name = "id"
      field_value = $input.driver_detail_id
    } as $driver_detail
  
    precondition ($driver_detail != null) {
      error_type = "notfound"
      error = "Not Found."
    }
  
    util.get_raw_input {
      encoding = "json"
      exclude_middleware = false
    } as $raw_input
  
    db.patch driver_detail {
      field_name = "id"
      field_value = $input.driver_detail_id
      data = `$input|pick:($raw_input|keys)`|filter_null|filter_empty_text
    } as $updated
  }

  response = $updated
  guid = "xM4S3d1G8p-DRIVER_DETAIL_PATCH"
}
