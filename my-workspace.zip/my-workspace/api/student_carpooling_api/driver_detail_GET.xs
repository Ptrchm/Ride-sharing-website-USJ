// Query driver detail records. Used by the frontend to discover driver verification details.
query driver_detail verb=GET {
  api_group = "Student Carpooling API"
  auth = "user"

  input {
  }

  stack {
    db.query driver_detail {
      return = {type: "list"}
    } as $driver_details
  }

  response = $driver_details
  guid = "Fqk0yqR4g8u3dD1k-driver_detail_get"
}
