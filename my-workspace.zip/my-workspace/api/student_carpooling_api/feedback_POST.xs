// Add feedback record
query feedback verb=POST {
  api_group = "Student Carpooling API"

  input {
    dblink {
      table = "feedback"
    }
  }

  stack {
    db.add feedback {
      data = {created_at: "now"}
    } as $feedback
  }

  response = $feedback
  guid = "FYj7Wsx2D2TRhsE4UtnumKzJn0o"
}