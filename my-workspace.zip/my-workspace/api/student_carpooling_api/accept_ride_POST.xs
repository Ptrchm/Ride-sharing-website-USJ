query accept_ride verb=POST {
  api_group = "Student Carpooling API"
  auth = "user"

  input {
    // The ID of the ride request to accept
    int ride_request_id
  }

  stack {
    db.get ride_request {
      field_name = "id"
      field_value = $input.ride_request_id
    } as $ride_request
  
    db.get user {
      field_name = "id"
      field_value = $ride_request.passenger_user_id
    } as $passenger
  
    db.edit ride_request {
      field_name = "id"
      field_value = $input.ride_request_id
      data = {status: "accepted"}
    } as $updated_request
  
    db.add accepted_ride {
      data = {
        ride_request_id  : $input.ride_request_id
        route_id         : $ride_request.route_id
        passenger_user_id: $ride_request.passenger_user_id
        driver_user_id   : $auth.id
        seats_booked     : 1
        status           : "confirmed"
      }
    } as $accepted_ride
  
    util.send_email {
      api_key = $env.RESEND_API_KEY
      service_provider = "resend"
      subject = "Your ride request has been accepted!"
      message = "Hello " ~ $passenger.full_name ~ ", your ride request has been accepted by the driver. Please check the app for more details."
      to = $passenger.email
      from = "no-reply@carpool.com"
    } as $email_response
  
    db.add event_log {
      data = {
        action  : "ride_request_accepted"
        user_id : $auth.id
        metadata: {
        ride_request_id: $input.ride_request_id
        passenger_id   : $passenger.id
      }
      }
    } as $event_log
  }

  response = $accepted_ride
  guid = "HMqQiRiR7KXsHbR4ENB5z6dpHUo"
}