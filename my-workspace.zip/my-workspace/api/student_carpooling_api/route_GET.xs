// Query all route records
query route verb=GET {
  api_group = "Student Carpooling API"

  input {
  }

  stack {
    db.query route {
      return = {type: "list"}
    } as $route
  }

  response = $route
  guid = "MG24HXVlijOSXHDpmyQMrtAMyjk"
}