// Endpoint path: POST /api/driver_detail. Frontend must send a multipart/form-data request to upload files.
query driver_detail verb=POST {
  api_group = "Student Carpooling API"
  auth = "user"

  input {
    // Car model
    text car_model
  
    // Car plate number
    text car_plate_number
  
    // Driver's license number
    text license_number
  
    // Phone number
    text phone_number filters=trim
  
    // License photo file
    file license_photo
  
    // Car registration photo file
    file car_registration_photo
  }

  stack {
    // INSTRUCTION: Ensure your frontend sets the 'Content-Type' header to 'multipart/form-data' when making the POST request to /api/driver_detail.
    // ADVICE: You can check if the fields contain actual file data by reviewing the debugger logs below. If they are empty or null, the frontend is not sending the files correctly.
  
    // Inspect incoming license_photo to verify file data is present
    debug.log {
      value = $input.license_photo
    }
  
    // Inspect incoming car_registration_photo to verify file data is present
    debug.log {
      value = $input.car_registration_photo
    }
  
    // Process and store the license photo
    storage.create_image {
      value = $input.license_photo
      access = "public"
      filename = "license.jpg"
    } as $stored_license_photo
  
    // Process and store the car registration photo
    storage.create_image {
      value = $input.car_registration_photo
      access = "public"
      filename = "registration.jpg"
    } as $stored_registration_photo
  
    // Retrieve the authenticated user to get their email
    db.get user {
      field_name = "id"
      field_value = $auth.id
    } as $user_record
  
    // Add or edit driver details, referencing the stored image objects
    db.add_or_edit driver_detail {
      field_name = "user_id"
      field_value = $auth.id
      data = {
        car_model             : $input.car_model
        car_plate_number      : $input.car_plate_number
        license_number        : $input.license_number
        phone_number          : $input.phone_number
        license_photo         : $stored_license_photo
        car_registration_photo: $stored_registration_photo
        status                : "pending"
        user_id               : $auth.id
        email                 : $user_record.email
      }
    } as $driver_detail_record
  }

  response = $driver_detail_record
  guid = "viw4H6V2ydzsWN-6dGvcHbgqspw"
}
