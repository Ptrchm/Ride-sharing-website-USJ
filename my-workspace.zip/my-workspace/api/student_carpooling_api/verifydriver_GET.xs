// Verifies if the authenticated user is a driver and returns their profile along with a driver flag.
query verifydriver verb=GET {
  api_group = "Student Carpooling API"
  auth = "user"

  input {
  }

  stack {
    db.query driver_detail {
      where = $db.driver_detail.user_id == $auth.id
      return = {type: "single"}
    } as $driver_detail
   
    // Fetch the user's profile from the user table
    db.get user {
      field_name = "id"
      field_value = $auth.id
    } as $user_profile
  
    // Prepare the final response object
    var $result {
      value = {
        profile      : $user_profile|set:"driver_status":$driver_detail.status
        is_driver    : false
        driver_detail: $driver_detail
      }
    }
  
    conditional {
      if ($driver_detail != null) {
        // Backward compatibility: older records may not have a status field set yet.
        conditional {
          if ($driver_detail.status == null || $driver_detail.status == "") {
            var.update $result {
              value = $result
                |set:"is_driver":true
                |set:"profile":($user_profile|set:"role":"driver"|set:"driver_status":"approved")
            }
          }
        }
      
        conditional {
          if ($driver_detail.status == "approved" || $driver_detail.status == "Approved") {
            var.update $result {
              value = $result
                |set:"is_driver":true
                |set:"profile":($user_profile|set:"role":"driver"|set:"driver_status":$driver_detail.status)
            }
          }
        }
      
        // Always expose a driver_status field (frontend treats null as pending).
        var.update $result {
          value = $result|set:"profile":($result.profile|set:"driver_status":$driver_detail.status)
        }
      }
    }
  }

  response = $result
  guid = "mpZnfg4yxmQnaRKh5VR_i07kKh8"
}
