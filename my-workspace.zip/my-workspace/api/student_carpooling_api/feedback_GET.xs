// Query all feedback records
query feedback verb=GET {
  api_group = "Student Carpooling API"

  input {
  }

  stack {
    db.query feedback {
      return = {type: "list"}
    } as $feedback
  }

  response = $feedback
  guid = "If2Ls7HBTga5NIQ0aY8k0EMmqyE"
}