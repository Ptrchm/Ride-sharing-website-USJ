// Query ride requests relevant to the authenticated user (as passenger or as route owner).
query ride_request verb=GET {
  api_group = "Student Carpooling API"
  auth = "user"

  input {
  }

  stack {
    db.query ride_request {
      // The frontend stores driver_user_id when creating a request, so drivers can list incoming requests
      // without needing a DB join (joins can vary by instance/template support).
      where = $db.ride_request.passenger_user_id == $auth.id || $db.ride_request.driver_user_id == $auth.id
      return = {type: "list"}
    } as $ride_requests
  }

  response = $ride_requests
  guid = "mHcJrWcwB3k7S9hDqv3x-ride_request_get"
}
