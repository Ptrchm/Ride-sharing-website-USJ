// Creates a new ride request after checking for scheduling conflicts.
query ride_request verb=POST {
  api_group = "Student Carpooling API"
  auth = "user"

  input {
    // The ID of the route being requested
    int route_id
  
    // The ID of the passenger requesting the ride
    int passenger_user_id
  
    // The ID of the driver offering the ride
    int driver_user_id
  }

  stack {
    precondition ($input.passenger_user_id == $auth.id) {
      error_type = "accessdenied"
      error = "You can only create ride requests for yourself."
    }
  
    // Fetch the route record using the provided route_id
    db.get route {
      field_name = "id"
      field_value = $input.route_id
    } as $route
  
    // Check if the user has an upcoming route as a driver
    db.query route {
      where = $db.route.user_id == $auth.id && $db.route.departure_time > now
      return = {type: "list"}
    } as $upcoming_driver_routes
  
    precondition (($upcoming_driver_routes|count) == 0) {
      error_type = "accessdenied"
      error = "Conflict: You have an upcoming route as a driver. Please wait until its departure time to request a new ride."
    }
  
    // Check if the user has a pending or accepted ride request for an upcoming route
    db.query ride_request {
      where = $db.ride_request.passenger_user_id == $auth.id && ($db.ride_request.status == "pending" || $db.ride_request.status == "accepted")
      return = {type: "list"}
    } as $upcoming_ride_requests
  
    precondition (($upcoming_ride_requests|count) == 0) {
      error_type = "accessdenied"
      error = "Conflict: You already have a pending or accepted ride request."
    }
  
    // Check if the user is already an accepted passenger for an upcoming route
    db.query accepted_ride {
      where = $db.accepted_ride.passenger_user_id == $auth.id
      return = {type: "list"}
    } as $upcoming_accepted_rides
  
    precondition (($upcoming_accepted_rides|count) == 0) {
      error_type = "accessdenied"
      error = "Conflict: You already have an accepted ride."
    }
  
    // Create the new ride request record
    db.add ride_request {
      data = {
        status           : "pending"
        route_id         : $input.route_id
        passenger_user_id: $input.passenger_user_id
        driver_user_id   : $input.driver_user_id
      }
    } as $new_ride_request
  }

  response = $new_ride_request
  guid = "l9w9_gex7ZXeaicN2IAqsTWeK8E"
}
