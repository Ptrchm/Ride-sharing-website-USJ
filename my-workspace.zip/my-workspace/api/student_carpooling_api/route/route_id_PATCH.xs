// Edit route record
query "route/{route_id}" verb=PATCH {
  api_group = "Student Carpooling API"

  input {
    int route_id? filters=min:1
    dblink {
      table = "route"
    }
  }

  stack {
    util.get_raw_input {
      encoding = "json"
      exclude_middleware = false
    } as $raw_input
  
    db.patch route {
      field_name = "id"
      field_value = $input.route_id
      data = `$input|pick:($raw_input|keys)`|filter_null|filter_empty_text
    } as $route
  }

  response = $route
  guid = "7yn4qBWA9p7V_oYAwS0Kd484ftc"
}