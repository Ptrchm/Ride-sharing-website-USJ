// Get route record
query "route/{route_id}" verb=GET {
  api_group = "Student Carpooling API"

  input {
    int route_id? filters=min:1
  }

  stack {
    db.get route {
      field_name = "id"
      field_value = $input.route_id
    } as $route
  
    precondition ($route != null) {
      error_type = "notfound"
      error = "Not Found."
    }
  }

  response = $route
  guid = "rXIbUUPTTDu2F_CRG-zH33F2rgw"
}