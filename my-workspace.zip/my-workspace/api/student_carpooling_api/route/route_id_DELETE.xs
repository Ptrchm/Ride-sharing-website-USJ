// Delete route record.
query "route/{route_id}" verb=DELETE {
  api_group = "Student Carpooling API"

  input {
    int route_id? filters=min:1
  }

  stack {
    db.del route {
      field_name = "id"
      field_value = $input.route_id
    }
  }

  response = null
  guid = "rXGN7gxh7W9GLYoO2Wd1tMuvmsY"
}