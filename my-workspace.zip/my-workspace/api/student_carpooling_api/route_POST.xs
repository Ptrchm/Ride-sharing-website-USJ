// Add route record
query route verb=POST {
  api_group = "Student Carpooling API"
  auth = "user"

  input {
    dblink {
      table = "route"
    }
  }

  stack {
    db.add route {
      data = {
        created_at             : "now"
        user_id                : $auth.id
        departure_location_name: $input.departure_location_name
        arrival_location_name  : $input.arrival_location_name
        departure_time         : $input.departure_time
        available_seats        : $input.available_seats
        price_per_seat         : $input.price_per_seat
        notes                  : $input.notes
        route_description      : $input.route_description
      }
    } as $route
  }

  response = $route
  guid = "L1uXyi3hnQxJL3MAtVGPXX3gC18"
}
