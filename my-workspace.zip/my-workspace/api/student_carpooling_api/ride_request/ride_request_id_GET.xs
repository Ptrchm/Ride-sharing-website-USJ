// Get ride_request record
query "ride_request/{ride_request_id}" verb=GET {
  api_group = "Student Carpooling API"

  input {
    int ride_request_id? filters=min:1
  }

  stack {
    db.get ride_request {
      field_name = "id"
      field_value = $input.ride_request_id
    } as $ride_request
  
    precondition ($ride_request != null) {
      error_type = "notfound"
      error = "Not Found."
    }
  }

  response = $ride_request
  guid = "aTbiDBCCefmX97ZgIrm6PrGArHI"
}