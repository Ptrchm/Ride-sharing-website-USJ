// Delete ride_request record.
query "ride_request/{ride_request_id}" verb=DELETE {
  api_group = "Student Carpooling API"

  input {
    int ride_request_id? filters=min:1
  }

  stack {
    db.del ride_request {
      field_name = "id"
      field_value = $input.ride_request_id
    }
  }

  response = null
  guid = "ywFReAFbQ-6_28YjXsIStQWA5FM"
}