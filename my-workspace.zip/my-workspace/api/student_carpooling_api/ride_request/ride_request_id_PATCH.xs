// Edit ride_request record
query "ride_request/{ride_request_id}" verb=PATCH {
  api_group = "Student Carpooling API"

  input {
    int ride_request_id? filters=min:1
    dblink {
      table = "ride_request"
    }
  }

  stack {
    util.get_raw_input {
      encoding = "json"
      exclude_middleware = false
    } as $raw_input
  
    db.patch ride_request {
      field_name = "id"
      field_value = $input.ride_request_id
      data = `$input|pick:($raw_input|keys)`|filter_null|filter_empty_text
    } as $ride_request
  }

  response = $ride_request
  guid = "j1XUdowZrCHPxUouMverPbICpVo"
}