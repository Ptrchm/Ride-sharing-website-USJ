table ride_request {
  auth = false

  schema {
    int id
    timestamp created_at?=now {
      visibility = "private"
    }
  
    text status?
  
    // References the specific ride route this request is for.
    int route_id? {
      table = "route"
    }
  
    // References the user who is the passenger for this ride request.
    int passenger_user_id? {
      table = "user"
    }
  
    // References the user who is the driver for this ride request.
    int driver_user_id? {
      table = "user"
    }
  }

  index = [
    {type: "primary", field: [{name: "id"}]}
    {type: "btree", field: [{name: "created_at", op: "desc"}]}
  ]

  guid = "IBULbNLVnTQaqh6nevEdm7cjDN4"
}