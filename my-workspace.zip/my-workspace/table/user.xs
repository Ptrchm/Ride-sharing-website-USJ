// Stores user information and allows the user to authenticate against
table user {
  auth = false

  schema {
    int id
    timestamp created_at?=now {
      visibility = "private"
    }
  
    // The full name of the user.
    text full_name? filters=trim

    // Optional role used by admin endpoints (e.g. "admin", "member").
    text role? filters=trim
  
    // The user's email address, used for login.
    email email? filters=trim|lower
  
    // The user's hashed password for authentication.
    password password?
  
    // Stores password reset token and expiration information.
    json password_reset?
  
    // Indicates if the user account is active.
    bool is_active?
  
    // Unique token used for email verification.
    text email_verification_token? filters=trim
  
    // Timestamp when the email verification token expires (in epoch milliseconds).
    timestamp email_verification_token_expires_at?
  
    // Reference to the account the user belongs to.
    int account_id? {
      table = "account"
    }
  }

  index = [
    {type: "primary", field: [{name: "id"}]}
    {type: "gin", field: [{name: "xdo", op: "jsonb_path_op"}]}
    {type: "btree", field: [{name: "created_at", op: "desc"}]}
    {type: "btree|unique", field: [{name: "email", op: "asc"}]}
  ]

  guid = "1VlpmL1sdWCWWZJoyEZju9eTdWw"
}
