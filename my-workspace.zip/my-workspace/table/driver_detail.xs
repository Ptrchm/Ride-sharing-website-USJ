table driver_detail {
  auth = false

  schema {
    int id
    timestamp created_at?=now {
      visibility = "private"
    }
  
    // Verification status for admin review: pending/approved/rejected.
    text status? filters=trim
  
    text car_model?
    text car_plate_number?
    text license_number?
  
    // The driver's phone number for contact.
    text phone_number? filters=trim
  
    // Photo of the driver's license for verification.
    image license_photo?
  
    // Photo of the car's registration document (carte grise) for verification.
    image car_registration_photo?
  
    // The email address of the driver.
    email email? filters=trim|lower
  
    // References the user who is the driver.
    int user_id? {
      table = "user"
    }
  }

  index = [
    {type: "primary", field: [{name: "id"}]}
    {type: "btree", field: [{name: "created_at", op: "desc"}]}
  ]

  guid = "Rv5SQwTLs33_h-uvaGdG09CCWA0"
}
