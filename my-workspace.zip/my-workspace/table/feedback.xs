table feedback {
  auth = false

  schema {
    int id
    timestamp created_at?=now {
      visibility = "private"
    }
  
    text message?
    int rating?
  
    // The email address of the user who provided the feedback.
    email email? filters=trim|lower
  }

  index = [
    {type: "primary", field: [{name: "id"}]}
    {type: "btree", field: [{name: "created_at", op: "desc"}]}
  ]

  guid = "dYXURLPf9YASuewc8yyLlXPGzsU"
}