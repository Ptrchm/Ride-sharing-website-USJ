table route {
  auth = false

  schema {
    int id
    timestamp created_at?=now {
      visibility = "private"
    }
  
    text route_description?
    bool recurring?
  
    // Number of available seats for the ride.
    int available_seats?
  
    // Price charged per seat for the ride.
    decimal price_per_seat?
  
    // Additional notes or instructions for the ride.
    text notes? filters=trim
  
    // The name of the departure location for the ride.
    text departure_location_name? filters=trim
  
    // The name of the arrival location for the ride.
    text arrival_location_name? filters=trim
  
    // The departure time of the ride in epoch milliseconds.
    timestamp departure_time?
  
    // References the user who created this route.
    int user_id? {
      table = "user"
    }
  }

  index = [
    {type: "primary", field: [{name: "id"}]}
    {type: "btree", field: [{name: "created_at", op: "desc"}]}
  ]

  guid = "WYyG-XYMAlXg06s8WUzknAlnfuY"
}