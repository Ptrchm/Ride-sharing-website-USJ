// Stores records of ride requests that have been accepted by a driver.
table accepted_ride {
  auth = false

  schema {
    int id
    timestamp created_at?=now {
      visibility = "private"
    }
  
    // References the original ride request that was accepted.
    int ride_request_id? {
      table = "ride_request"
    }
  
    // References the specific route for which the ride was accepted.
    int route_id? {
      table = "route"
    }
  
    // References the user who is the passenger for this accepted ride.
    int passenger_user_id? {
      table = "user"
    }
  
    // References the user who is the driver for this accepted ride.
    int driver_user_id? {
      table = "user"
    }
  
    // The number of seats booked by this passenger for this ride, usually 1.
    int seats_booked?
  
    // The current status of the accepted ride (e.g., confirmed, completed, cancelled).
    enum status? {
      values = ["confirmed", "completed", "cancelled"]
    }
  }

  index = [
    {type: "primary", field: [{name: "id"}]}
    {type: "gin", field: [{name: "xdo", op: "jsonb_path_op"}]}
    {type: "btree", field: [{name: "created_at", op: "desc"}]}
  ]

  guid = "FZN8OOkGwQHzA9RsS7Iy1F8X51s"
}