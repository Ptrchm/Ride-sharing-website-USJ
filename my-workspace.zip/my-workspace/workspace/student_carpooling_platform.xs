// A web application designed to connect university students for carpooling, allowing them to register as either drivers offering rides or passengers seeking rides. It includes features for route management, ride requests, user authentication with role-based access, and an administrative interface for managing users and routes.
workspace "Student Carpooling Platform" {
  acceptance = {ai_terms: false}
  preferences = {
    internal_docs    : false
    track_performance: true
    sql_names        : false
    sql_columns      : true
  }
}