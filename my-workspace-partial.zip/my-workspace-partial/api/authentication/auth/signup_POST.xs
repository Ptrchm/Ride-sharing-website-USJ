query "auth/signup" verb=POST {
  api_group = "Authentication"

  input {
    text name?
    email email {
      sensitive = true
    }
  
    password password {
      sensitive = true
    }
  }

  stack {
    // Check if a user with this email already exists
    db.get user {
      field_name = "email"
      field_value = $input.email
    } as $existing_user
  
    precondition ($existing_user == null) {
      error_type = "accessdenied"
      error = "This account is already in use."
    }
  
    // Create a new user record with provided details
    db.add user {
      data = {
        full_name: $input.name
        email    : $input.email
        password : $input.password
        is_active: false
      }
    } as $user
  
    // Generate an authentication token for the new user
    security.create_auth_token {
      table = "user"
      extras = {}
      expiration = 86400
      id = $user.id
    } as $auth_token
  }

  response = {auth_token: $auth_token}
  guid = "g6E8E2wr8FPWccUg-4Qqxu2csFg"
}
